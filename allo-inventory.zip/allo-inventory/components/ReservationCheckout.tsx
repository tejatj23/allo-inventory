"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { ReservationWithDetails } from "@/lib/schemas";
import { useCountdown } from "@/hooks/useCountdown";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Clock,
  CheckCircle2,
  XCircle,
  Package,
  MapPin,
  ShoppingBag,
} from "lucide-react";

interface ReservationCheckoutProps {
  reservation: ReservationWithDetails;
}

type ActionResult = {
  type: "success" | "error";
  title: string;
  message: string;
};

export function ReservationCheckout({ reservation: initial }: ReservationCheckoutProps) {
  const [reservation, setReservation] = useState(initial);
  const [loading, setLoading] = useState<"confirm" | "cancel" | null>(null);
  const [result, setResult] = useState<ActionResult | null>(null);
  const router = useRouter();

  const { formatted, isExpired, totalSeconds } = useCountdown(reservation.expiresAt);

  const isPending = reservation.status === "PENDING";
  const isConfirmed = reservation.status === "CONFIRMED";
  const isReleased = reservation.status === "RELEASED";

  const handleConfirm = async () => {
    setLoading("confirm");
    setResult(null);
    try {
      const res = await fetch(`/api/reservations/${reservation.id}/confirm`, {
        method: "POST",
      });
      const json = await res.json();

      if (!res.ok) {
        if (res.status === 410) {
          setResult({
            type: "error",
            title: "Reservation Expired",
            message: "Your reservation expired before payment could be completed. The items have been returned to stock.",
          });
          setReservation((r) => ({ ...r, status: "RELEASED" }));
        } else {
          setResult({
            type: "error",
            title: "Confirmation Failed",
            message: json.error || "Could not confirm your order. Please try again.",
          });
        }
        return;
      }

      setReservation(json.data);
      setResult({
        type: "success",
        title: "Order Confirmed!",
        message: `Your order for ${reservation.product.name} has been confirmed. Thank you for your purchase!`,
      });
    } finally {
      setLoading(null);
    }
  };

  const handleCancel = async () => {
    setLoading("cancel");
    setResult(null);
    try {
      const res = await fetch(`/api/reservations/${reservation.id}/release`, {
        method: "POST",
      });
      const json = await res.json();

      if (!res.ok) {
        setResult({
          type: "error",
          title: "Cancellation Failed",
          message: json.error || "Could not cancel. Please try again.",
        });
        return;
      }

      setReservation(json.data);
      setResult({
        type: "success",
        title: "Reservation Cancelled",
        message: "Your reservation has been released. The items are back in stock.",
      });
    } finally {
      setLoading(null);
    }
  };

  const statusBadge = () => {
    if (isConfirmed) return <Badge variant="success">Confirmed</Badge>;
    if (isReleased) return <Badge variant="warning">Released</Badge>;
    if (isExpired) return <Badge variant="destructive">Expired</Badge>;
    return <Badge variant="pending">Pending</Badge>;
  };

  const timerColor =
    totalSeconds > 120 ? "text-emerald-600" : totalSeconds > 60 ? "text-amber-600" : "text-red-600";

  return (
    <div className="max-w-lg mx-auto space-y-6">
      {/* Status alert */}
      {result && (
        <Alert variant={result.type === "success" ? "success" : "destructive"}>
          {result.type === "success" ? (
            <CheckCircle2 className="h-4 w-4" />
          ) : (
            <XCircle className="h-4 w-4" />
          )}
          <AlertTitle>{result.title}</AlertTitle>
          <AlertDescription>{result.message}</AlertDescription>
        </Alert>
      )}

      {/* Expiry alert for active reservation */}
      {isPending && isExpired && (
        <Alert variant="destructive">
          <Clock className="h-4 w-4" />
          <AlertTitle>Reservation Expired</AlertTitle>
          <AlertDescription>
            Your hold has expired. The items have been returned to the available stock.
          </AlertDescription>
        </Alert>
      )}

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <ShoppingBag className="h-5 w-5" />
              Checkout
            </CardTitle>
            {statusBadge()}
          </div>
          <p className="text-sm text-slate-500">Reservation #{reservation.id.slice(-8).toUpperCase()}</p>
        </CardHeader>

        <CardContent className="space-y-6">
          {/* Product details */}
          <div className="flex gap-4 p-4 bg-slate-50 rounded-lg">
            {reservation.product.imageUrl && (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={reservation.product.imageUrl}
                alt={reservation.product.name}
                className="w-16 h-16 object-cover rounded-md flex-shrink-0"
              />
            )}
            <div className="flex-1 min-w-0">
              <p className="font-semibold truncate">{reservation.product.name}</p>
              <div className="flex items-center gap-1 text-sm text-slate-500 mt-1">
                <MapPin className="h-3 w-3 flex-shrink-0" />
                <span>{reservation.warehouse.name} · {reservation.warehouse.location}</span>
              </div>
              <div className="flex items-center gap-1 text-sm text-slate-500 mt-0.5">
                <Package className="h-3 w-3 flex-shrink-0" />
                <span>Qty: {reservation.quantity}</span>
              </div>
            </div>
            <div className="text-right flex-shrink-0">
              <p className="font-bold text-lg">
                ₹{(reservation.product.price * reservation.quantity).toLocaleString("en-IN")}
              </p>
            </div>
          </div>

          {/* Countdown timer */}
          {isPending && !isExpired && (
            <div className="text-center p-4 border border-dashed border-slate-200 rounded-lg">
              <p className="text-xs text-slate-500 uppercase tracking-wide mb-1">
                Reservation expires in
              </p>
              <p className={`text-4xl font-mono font-bold ${timerColor}`}>
                {formatted}
              </p>
              <p className="text-xs text-slate-400 mt-1">
                Complete your purchase before the timer runs out
              </p>
            </div>
          )}

          {/* Action buttons */}
          {isPending && !isExpired && (
            <div className="flex gap-3">
              <Button
                variant="success"
                className="flex-1"
                onClick={handleConfirm}
                disabled={loading !== null}
              >
                {loading === "confirm" ? (
                  <span className="flex items-center gap-2">
                    <span className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
                    Processing...
                  </span>
                ) : (
                  <span className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4" />
                    Confirm Purchase
                  </span>
                )}
              </Button>
              <Button
                variant="outline"
                className="flex-1"
                onClick={handleCancel}
                disabled={loading !== null}
              >
                {loading === "cancel" ? (
                  <span className="flex items-center gap-2">
                    <span className="h-4 w-4 animate-spin rounded-full border-2 border-slate-400 border-t-transparent" />
                    Cancelling...
                  </span>
                ) : (
                  <span className="flex items-center gap-2">
                    <XCircle className="h-4 w-4" />
                    Cancel
                  </span>
                )}
              </Button>
            </div>
          )}

          {/* Post-action links */}
          {(isConfirmed || isReleased || isExpired) && (
            <Button
              variant="secondary"
              className="w-full"
              onClick={() => router.push("/")}
            >
              Back to Products
            </Button>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
