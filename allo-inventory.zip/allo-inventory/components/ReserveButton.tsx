"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { ShoppingCart, AlertCircle } from "lucide-react";
import { ProductWithStock } from "@/lib/schemas";

interface ReserveButtonProps {
  product: ProductWithStock;
  warehouseId: string;
  warehouseName: string;
  availableUnits: number;
}

export function ReserveButton({
  product,
  warehouseId,
  warehouseName,
  availableUnits,
}: ReserveButtonProps) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();

  const handleReserve = async () => {
    setLoading(true);
    setError(null);

    try {
      const res = await fetch("/api/reservations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          productId: product.id,
          warehouseId,
          quantity: 1,
        }),
      });

      const json = await res.json();

      if (!res.ok) {
        if (res.status === 409) {
          setError("Out of stock — someone just grabbed the last unit!");
        } else {
          setError(json.error || "Failed to reserve. Please try again.");
        }
        return;
      }

      // Navigate to checkout page
      router.push(`/reservations/${json.data.id}`);
    } catch {
      setError("Network error. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  if (availableUnits === 0) {
    return (
      <Button variant="secondary" size="sm" disabled className="w-full">
        Out of Stock
      </Button>
    );
  }

  return (
    <div className="space-y-1">
      <Button
        variant="default"
        size="sm"
        onClick={handleReserve}
        disabled={loading}
        className="w-full"
      >
        {loading ? (
          <span className="flex items-center gap-2">
            <span className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
            Reserving...
          </span>
        ) : (
          <span className="flex items-center gap-2">
            <ShoppingCart className="h-4 w-4" />
            Reserve — {warehouseName}
          </span>
        )}
      </Button>
      {error && (
        <p className="flex items-center gap-1 text-xs text-red-600">
          <AlertCircle className="h-3 w-3 flex-shrink-0" />
          {error}
        </p>
      )}
    </div>
  );
}
