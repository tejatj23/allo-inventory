import Image from "next/image";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ReserveButton } from "./ReserveButton";
import { ProductWithStock } from "@/lib/schemas";

interface ProductCardProps {
  product: ProductWithStock;
}

export function ProductCard({ product }: ProductCardProps) {
  const totalAvailable = product.stockLevels.reduce(
    (sum, sl) => sum + sl.availableUnits,
    0
  );

  return (
    <Card className="flex flex-col overflow-hidden hover:shadow-md transition-shadow">
      {product.imageUrl && (
        <div className="relative h-48 w-full bg-slate-50">
          <Image
            src={product.imageUrl}
            alt={product.name}
            fill
            className="object-cover"
            sizes="(max-width: 768px) 100vw, 33vw"
          />
        </div>
      )}
      <CardHeader className="pb-2">
        <div className="flex items-start justify-between gap-2">
          <CardTitle className="text-base leading-tight">{product.name}</CardTitle>
          <Badge variant={totalAvailable > 0 ? "success" : "destructive"}>
            {totalAvailable > 0 ? `${totalAvailable} avail.` : "Out of stock"}
          </Badge>
        </div>
        {product.description && (
          <p className="text-sm text-slate-500 line-clamp-2">{product.description}</p>
        )}
        <p className="text-lg font-bold text-slate-900">
          ₹{product.price.toLocaleString("en-IN")}
        </p>
      </CardHeader>

      <CardContent className="flex-1 space-y-3">
        <div className="space-y-2">
          <p className="text-xs font-medium text-slate-500 uppercase tracking-wide">
            Stock by Warehouse
          </p>
          {product.stockLevels.map((sl) => (
            <div key={sl.warehouseId} className="space-y-1">
              <div className="flex items-center justify-between text-sm">
                <span className="font-medium">{sl.warehouseName}</span>
                <span className="text-slate-500 text-xs">{sl.warehouseLocation}</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="flex-1 bg-slate-100 rounded-full h-1.5">
                  <div
                    className="bg-emerald-500 h-1.5 rounded-full transition-all"
                    style={{
                      width: sl.totalUnits === 0 ? "0%" : `${(sl.availableUnits / sl.totalUnits) * 100}%`,
                    }}
                  />
                </div>
                <span className="text-xs text-slate-600 w-16 text-right">
                  {sl.availableUnits}/{sl.totalUnits} units
                </span>
              </div>
              <ReserveButton
                product={product}
                warehouseId={sl.warehouseId}
                warehouseName={sl.warehouseName}
                availableUnits={sl.availableUnits}
              />
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
