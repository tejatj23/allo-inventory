"use client";

import { useState, useEffect, useCallback } from "react";

interface CountdownResult {
  minutes: number;
  seconds: number;
  totalSeconds: number;
  isExpired: boolean;
  formatted: string;
}

export function useCountdown(expiresAt: string | Date): CountdownResult {
  const getRemaining = useCallback(() => {
    const expiry = new Date(expiresAt).getTime();
    const now = Date.now();
    return Math.max(0, Math.floor((expiry - now) / 1000));
  }, [expiresAt]);

  const [totalSeconds, setTotalSeconds] = useState(getRemaining);

  useEffect(() => {
    const interval = setInterval(() => {
      setTotalSeconds(getRemaining());
    }, 1000);
    return () => clearInterval(interval);
  }, [getRemaining]);

  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  const isExpired = totalSeconds === 0;

  const formatted = isExpired
    ? "Expired"
    : `${minutes}:${seconds.toString().padStart(2, "0")}`;

  return { minutes, seconds, totalSeconds, isExpired, formatted };
}
