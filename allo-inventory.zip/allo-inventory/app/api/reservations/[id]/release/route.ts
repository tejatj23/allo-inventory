import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function POST(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;

  try {
    const result = await prisma.$transaction(async (tx) => {
      const reservation = await tx.reservation.findUnique({ where: { id } });

      if (!reservation) {
        throw new Error("NOT_FOUND");
      }

      if (reservation.status === "RELEASED") {
        // Already released — idempotent
        return reservation;
      }

      if (reservation.status === "CONFIRMED") {
        throw new Error("ALREADY_CONFIRMED");
      }

      // Release: decrement reservedUnits to return them to available pool
      await tx.stockLevel.update({
        where: {
          productId_warehouseId: {
            productId: reservation.productId,
            warehouseId: reservation.warehouseId,
          },
        },
        data: {
          reservedUnits: { decrement: reservation.quantity },
        },
      });

      const released = await tx.reservation.update({
        where: { id },
        data: { status: "RELEASED" },
        include: {
          product: { select: { id: true, name: true, price: true, imageUrl: true } },
          warehouse: { select: { id: true, name: true, location: true } },
        },
      });

      return released;
    });

    return NextResponse.json({ data: result });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "";

    if (message === "NOT_FOUND") {
      return NextResponse.json({ error: "Reservation not found." }, { status: 404 });
    }
    if (message === "ALREADY_CONFIRMED") {
      return NextResponse.json(
        { error: "Cannot release a confirmed reservation." },
        { status: 409 }
      );
    }

    console.error(`POST /api/reservations/${id}/release error:`, error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
