import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import {
  getIdempotencyResponse,
  setIdempotencyResponse,
} from "@/lib/redis";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const idempotencyKey = request.headers.get("Idempotency-Key");

  try {
    // --- Bonus: Idempotency ---
    if (idempotencyKey) {
      const cached = await getIdempotencyResponse(`confirm:${idempotencyKey}`);
      if (cached) {
        return NextResponse.json(cached, {
          headers: { "X-Idempotent-Replayed": "true" },
        });
      }
    }

    const result = await prisma.$transaction(async (tx) => {
      const reservation = await tx.reservation.findUnique({
        where: { id },
        include: {
          product: { select: { id: true, name: true, price: true, imageUrl: true } },
          warehouse: { select: { id: true, name: true, location: true } },
        },
      });

      if (!reservation) {
        throw new Error("NOT_FOUND");
      }

      if (reservation.status === "CONFIRMED") {
        // Already confirmed — idempotent success
        return reservation;
      }

      if (reservation.status === "RELEASED") {
        throw new Error("ALREADY_RELEASED");
      }

      // Check expiry
      if (reservation.expiresAt < new Date()) {
        // Lazy cleanup: release the reservation and free stock
        await tx.stockLevel.update({
          where: {
            productId_warehouseId: {
              productId: reservation.productId,
              warehouseId: reservation.warehouseId,
            },
          },
          data: {
            reservedUnits: { decrement: reservation.quantity },
          },
        });

        await tx.reservation.update({
          where: { id },
          data: { status: "RELEASED" },
        });

        throw new Error("EXPIRED");
      }

      // Confirm: mark as confirmed.
      // Reserved units stay accounted for — they are now permanently consumed.
      // Decrement totalUnits to reflect the actual sale, and release reservedUnits.
      await tx.stockLevel.update({
        where: {
          productId_warehouseId: {
            productId: reservation.productId,
            warehouseId: reservation.warehouseId,
          },
        },
        data: {
          totalUnits: { decrement: reservation.quantity },
          reservedUnits: { decrement: reservation.quantity },
        },
      });

      const confirmed = await tx.reservation.update({
        where: { id },
        data: { status: "CONFIRMED" },
        include: {
          product: { select: { id: true, name: true, price: true, imageUrl: true } },
          warehouse: { select: { id: true, name: true, location: true } },
        },
      });

      return confirmed;
    });

    const responseBody = { data: result };

    if (idempotencyKey) {
      await setIdempotencyResponse(`confirm:${idempotencyKey}`, responseBody);
    }

    return NextResponse.json(responseBody);
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "";

    if (message === "NOT_FOUND") {
      return NextResponse.json({ error: "Reservation not found." }, { status: 404 });
    }
    if (message === "EXPIRED") {
      return NextResponse.json(
        { error: "This reservation has expired and cannot be confirmed." },
        { status: 410 }
      );
    }
    if (message === "ALREADY_RELEASED") {
      return NextResponse.json(
        { error: "This reservation was already released and cannot be confirmed." },
        { status: 409 }
      );
    }

    console.error(`POST /api/reservations/${id}/confirm error:`, error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
