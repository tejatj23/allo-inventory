import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import {
  acquireLock,
  releaseLock,
  getIdempotencyResponse,
  setIdempotencyResponse,
} from "@/lib/redis";
import { CreateReservationSchema } from "@/lib/schemas";

// Reservation window: 10 minutes
const RESERVATION_TTL_MINUTES = 10;

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const idempotencyKey = request.headers.get("Idempotency-Key");

    // --- Bonus: Idempotency ---
    if (idempotencyKey) {
      const cached = await getIdempotencyResponse(idempotencyKey);
      if (cached) {
        return NextResponse.json(cached, {
          headers: { "X-Idempotent-Replayed": "true" },
        });
      }
    }

    // --- Input validation ---
    const parsed = CreateReservationSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { error: "Invalid request body", details: parsed.error.flatten() },
        { status: 400 }
      );
    }

    const { productId, warehouseId, quantity } = parsed.data;

    // --- Distributed lock per product+warehouse ---
    // This ensures only ONE request at a time can modify stock for this SKU.
    const lockKey = `stock:${productId}:${warehouseId}`;
    const lockAcquired = await acquireLock(lockKey, 15);

    if (!lockAcquired) {
      return NextResponse.json(
        {
          error:
            "Another request is being processed for this item. Please try again.",
        },
        { status: 429 }
      );
    }

    try {
      // --- Critical section: check-and-reserve atomically via Prisma transaction ---
      const result = await prisma.$transaction(async (tx) => {
        // Re-read stock inside transaction for serializable isolation
        const stockLevel = await tx.stockLevel.findUnique({
          where: {
            productId_warehouseId: { productId, warehouseId },
          },
        });

        if (!stockLevel) {
          throw new Error("STOCK_NOT_FOUND");
        }

        const available = stockLevel.totalUnits - stockLevel.reservedUnits;

        if (available < quantity) {
          throw new Error("INSUFFICIENT_STOCK");
        }

        // Atomically increment reservedUnits
        const updatedStock = await tx.stockLevel.update({
          where: {
            productId_warehouseId: { productId, warehouseId },
          },
          data: {
            reservedUnits: { increment: quantity },
          },
        });

        // Verify no over-reservation after increment (double-check)
        if (updatedStock.reservedUnits > updatedStock.totalUnits) {
          throw new Error("INSUFFICIENT_STOCK");
        }

        // Create the reservation
        const expiresAt = new Date(
          Date.now() + RESERVATION_TTL_MINUTES * 60 * 1000
        );

        const reservation = await tx.reservation.create({
          data: {
            productId,
            warehouseId,
            quantity,
            status: "PENDING",
            expiresAt,
            idempotencyKey: idempotencyKey ?? undefined,
          },
          include: {
            product: { select: { id: true, name: true, price: true, imageUrl: true } },
            warehouse: { select: { id: true, name: true, location: true } },
          },
        });

        return reservation;
      });

      const responseBody = { data: result };

      // Cache idempotency response
      if (idempotencyKey) {
        await setIdempotencyResponse(idempotencyKey, responseBody);
      }

      return NextResponse.json(responseBody, { status: 201 });
    } catch (txError: unknown) {
      const message = txError instanceof Error ? txError.message : "";

      if (message === "INSUFFICIENT_STOCK") {
        return NextResponse.json(
          { error: "Not enough stock available for this product/warehouse." },
          { status: 409 }
        );
      }
      if (message === "STOCK_NOT_FOUND") {
        return NextResponse.json(
          { error: "Product is not stocked at this warehouse." },
          { status: 404 }
        );
      }

      // Idempotency key conflict (duplicate reservation with same key)
      if (
        message.includes("Unique constraint") &&
        message.includes("idempotencyKey")
      ) {
        return NextResponse.json(
          { error: "Duplicate idempotency key." },
          { status: 409 }
        );
      }

      throw txError;
    } finally {
      await releaseLock(lockKey);
    }
  } catch (error) {
    console.error("POST /api/reservations error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}

export async function GET() {
  try {
    const reservations = await prisma.reservation.findMany({
      include: {
        product: { select: { id: true, name: true, price: true, imageUrl: true } },
        warehouse: { select: { id: true, name: true, location: true } },
      },
      orderBy: { createdAt: "desc" },
    });
    return NextResponse.json({ data: reservations });
  } catch (error) {
    console.error("GET /api/reservations error:", error);
    return NextResponse.json(
      { error: "Failed to fetch reservations" },
      { status: 500 }
    );
  }
}
