import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

/**
 * Cron endpoint to clean up expired PENDING reservations.
 * 
 * Configure in vercel.json:
 * {
 *   "crons": [{ "path": "/api/cron/cleanup-reservations", "schedule": "* * * * *" }]
 * }
 * 
 * Secured with CRON_SECRET env var (set in Vercel project settings).
 */
export async function GET(request: NextRequest) {
  const authHeader = request.headers.get("authorization");
  const cronSecret = process.env.CRON_SECRET;

  if (cronSecret && authHeader !== `Bearer ${cronSecret}`) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const now = new Date();

    // Find all expired PENDING reservations
    const expiredReservations = await prisma.reservation.findMany({
      where: {
        status: "PENDING",
        expiresAt: { lt: now },
      },
    });

    if (expiredReservations.length === 0) {
      return NextResponse.json({ released: 0 });
    }

    // Release each in a transaction: decrement reservedUnits, update status
    let released = 0;

    for (const reservation of expiredReservations) {
      try {
        await prisma.$transaction(async (tx: typeof prisma) => {
          // Re-check status inside transaction to avoid double-release
          const current = await tx.reservation.findUnique({
            where: { id: reservation.id },
            select: { status: true },
          });

          if (!current || current.status !== "PENDING") return;

          await tx.stockLevel.update({
            where: {
              productId_warehouseId: {
                productId: reservation.productId,
                warehouseId: reservation.warehouseId,
              },
            },
            data: {
              reservedUnits: { decrement: reservation.quantity },
            },
          });

          await tx.reservation.update({
            where: { id: reservation.id },
            data: { status: "RELEASED" },
          });

          released++;
        });
      } catch (err) {
        console.error(`Failed to release reservation ${reservation.id}:`, err);
      }
    }

    console.log(`Cron cleanup: released ${released} expired reservations.`);
    return NextResponse.json({ released });
  } catch (error) {
    console.error("Cron cleanup error:", error);
    return NextResponse.json({ error: "Cleanup failed" }, { status: 500 });
  }
}
