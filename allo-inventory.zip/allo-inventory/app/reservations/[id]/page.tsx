import { notFound } from "next/navigation";
import { ReservationCheckout } from "@/components/ReservationCheckout";
import { ReservationWithDetails } from "@/lib/schemas";

async function getReservation(id: string): Promise<ReservationWithDetails | null> {
  const baseUrl = process.env.NEXTAUTH_URL || "http://localhost:3000";
  const res = await fetch(`${baseUrl}/api/reservations/${id}`, {
    cache: "no-store",
  });
  if (res.status === 404) return null;
  if (!res.ok) throw new Error("Failed to load reservation");
  const json = await res.json();
  return json.data;
}

interface Props {
  params: Promise<{ id: string }>;
}

export default async function ReservationPage({ params }: Props) {
  const { id } = await params;
  const reservation = await getReservation(id);

  if (!reservation) {
    notFound();
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Complete Your Purchase</h1>
        <p className="text-slate-500 mt-1">
          Your item is reserved. Complete payment before the timer expires.
        </p>
      </div>
      <ReservationCheckout reservation={reservation} />
    </div>
  );
}
