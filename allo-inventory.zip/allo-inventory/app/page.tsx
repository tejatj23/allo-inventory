import { ProductCard } from "@/components/ProductCard";
import { ProductWithStock } from "@/lib/schemas";

async function getProducts(): Promise<ProductWithStock[]> {
  // Server component — fetch from our own API
  const baseUrl = process.env.NEXTAUTH_URL || "http://localhost:3000";
  const res = await fetch(`${baseUrl}/api/products`, {
    cache: "no-store", // Always fresh for inventory
  });
  if (!res.ok) throw new Error("Failed to load products");
  const json = await res.json();
  return json.data;
}

export default async function ProductsPage() {
  let products: ProductWithStock[] = [];
  let error: string | null = null;

  try {
    products = await getProducts();
  } catch {
    error = "Failed to load products. Please refresh.";
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Products</h1>
        <p className="text-slate-500 mt-1">
          Reserve items for 10 minutes while you complete checkout.
        </p>
      </div>

      {error && (
        <div className="rounded-lg border border-red-200 bg-red-50 p-4 text-red-800 text-sm">
          {error}
        </div>
      )}

      {products.length === 0 && !error && (
        <div className="text-center py-16 text-slate-400">
          <p className="text-lg">No products found.</p>
          <p className="text-sm mt-1">Run the seed script to add sample data.</p>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {products.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </div>
  );
}
