import Link from "next/link";
import { Button } from "@/components/ui/button";

export default function NotFound() {
  return (
    <div className="text-center py-16 space-y-4">
      <h2 className="text-2xl font-bold text-slate-900">Page Not Found</h2>
      <p className="text-slate-500">The reservation or page you&apos;re looking for doesn&apos;t exist.</p>
      <Link href="/">
        <Button>Back to Products</Button>
      </Link>
    </div>
  );
}
