import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  console.log("🌱 Seeding database...");

  // Clean up existing data
  await prisma.reservation.deleteMany();
  await prisma.stockLevel.deleteMany();
  await prisma.product.deleteMany();
  await prisma.warehouse.deleteMany();

  // Create warehouses
  const warehouseMumbai = await prisma.warehouse.create({
    data: { name: "Mumbai Central", location: "Mumbai, MH" },
  });
  const warehouseDelhi = await prisma.warehouse.create({
    data: { name: "Delhi North", location: "Delhi, DL" },
  });
  const warehouseBangalore = await prisma.warehouse.create({
    data: { name: "Bengaluru Tech Park", location: "Bangalore, KA" },
  });

  console.log("✅ Warehouses created");

  // Create products
  const products = await Promise.all([
    prisma.product.create({
      data: {
        name: "Wireless Noise-Cancelling Headphones",
        description: "Premium over-ear headphones with 30hr battery and ANC.",
        price: 8999,
        imageUrl: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400",
      },
    }),
    prisma.product.create({
      data: {
        name: "Mechanical Keyboard",
        description: "TKL layout, Cherry MX switches, RGB backlight.",
        price: 6499,
        imageUrl: "https://images.unsplash.com/photo-1618384887929-16ec33fab9ef?w=400",
      },
    }),
    prisma.product.create({
      data: {
        name: "USB-C Hub 7-in-1",
        description: "HDMI 4K, 3x USB-A, SD card, 100W PD passthrough.",
        price: 2499,
        imageUrl: "https://images.unsplash.com/photo-1625723044792-44de16ccb4e9?w=400",
      },
    }),
    prisma.product.create({
      data: {
        name: "Ergonomic Office Chair",
        description: "Lumbar support, adjustable armrests, mesh back.",
        price: 24999,
        imageUrl: "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=400",
      },
    }),
    prisma.product.create({
      data: {
        name: "4K Webcam",
        description: "Auto-focus, built-in ring light, 90° FOV.",
        price: 4999,
        imageUrl: "https://images.unsplash.com/photo-1587826080692-f439cd0b70da?w=400",
      },
    }),
  ]);

  console.log("✅ Products created");

  // Create stock levels — low quantities to make race conditions testable
  const stockData = [
    { productIdx: 0, warehouseId: warehouseMumbai.id, total: 5 },
    { productIdx: 0, warehouseId: warehouseDelhi.id, total: 3 },
    { productIdx: 1, warehouseId: warehouseMumbai.id, total: 8 },
    { productIdx: 1, warehouseId: warehouseBangalore.id, total: 2 },
    { productIdx: 2, warehouseId: warehouseDelhi.id, total: 10 },
    { productIdx: 2, warehouseId: warehouseBangalore.id, total: 6 },
    { productIdx: 3, warehouseId: warehouseMumbai.id, total: 1 }, // Only 1 unit — good for race condition demo
    { productIdx: 3, warehouseId: warehouseDelhi.id, total: 3 },
    { productIdx: 4, warehouseId: warehouseBangalore.id, total: 4 },
    { productIdx: 4, warehouseId: warehouseMumbai.id, total: 2 },
  ];

  for (const s of stockData) {
    await prisma.stockLevel.create({
      data: {
        productId: products[s.productIdx].id,
        warehouseId: s.warehouseId,
        totalUnits: s.total,
        reservedUnits: 0,
      },
    });
  }

  console.log("✅ Stock levels created");
  console.log("🎉 Seed complete!");
}

main()
  .catch((e) => {
    console.error("Seed failed:", e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
