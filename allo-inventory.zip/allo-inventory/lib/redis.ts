import { createClient } from "redis";

const globalForRedis = globalThis as unknown as {
  redis: ReturnType<typeof createClient> | undefined;
};

function createRedisClient() {
  const client = createClient({
    url: process.env.REDIS_URL || "redis://localhost:6379",
  });

  client.on("error", (err) => {
    console.error("Redis Client Error", err);
  });

  return client;
}

export const redis = globalForRedis.redis ?? createRedisClient();

if (process.env.NODE_ENV !== "production") globalForRedis.redis = redis;

let connected = false;

export async function getRedis() {
  if (!connected) {
    await redis.connect();
    connected = true;
  }
  return redis;
}

/**
 * Acquire a distributed lock using SET NX EX (atomic).
 * Returns true if lock was acquired, false if already locked.
 */
export async function acquireLock(
  key: string,
  ttlSeconds: number = 10
): Promise<boolean> {
  const client = await getRedis();
  const result = await client.set(`lock:${key}`, "1", {
    NX: true,
    EX: ttlSeconds,
  });
  return result === "OK";
}

/**
 * Release a distributed lock.
 */
export async function releaseLock(key: string): Promise<void> {
  const client = await getRedis();
  await client.del(`lock:${key}`);
}

/**
 * Store an idempotency response.
 * TTL = 24 hours (86400 seconds)
 */
export async function setIdempotencyResponse(
  key: string,
  response: object,
  ttlSeconds: number = 86400
): Promise<void> {
  const client = await getRedis();
  await client.set(`idempotency:${key}`, JSON.stringify(response), {
    EX: ttlSeconds,
  });
}

/**
 * Retrieve a stored idempotency response.
 */
export async function getIdempotencyResponse(
  key: string
): Promise<object | null> {
  const client = await getRedis();
  const data = await client.get(`idempotency:${key}`);
  if (!data) return null;
  return JSON.parse(data);
}
